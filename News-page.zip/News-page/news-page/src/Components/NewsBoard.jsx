import { useEffect, useState } from "react";
import NewsItem from "./NewsItem";

const NewsBoard = () => {
  const [newsItems, setNewsItems] = useState([]);

  useEffect(() => {
    fetch('https://newsapi.org/v2/everything?q=crime&apiKey=e92ec81f9b6c49deb1ad5a831207b64f')
      .then((response) => response.json())
      .then((data) => {
        const fetchedNews = data.articles.map((article) => ({
          title: article.title,
          description: article.description,
          image: article.urlToImage, 
          url: article.url,
        }));
        setNewsItems(fetchedNews);
      });
  }, []);

  return (
    <div>
      <h2 className="text-center">Latest <span className="badge bg-danger">News</span></h2>
      {newsItems.map((news, index) => (
        <NewsItem 
          key={index} 
          title={news.title} 
          description={news.description} 
          src={news.image} 
          url={news.url} 
        />
      ))}
    </div>
  );
};

export default NewsBoard;
