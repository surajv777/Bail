import Navbar from "./Components/Navbar";
import NewsBoard from "./Components/NewsBoard";

const App = () => {
  return (
    <div>
      <Navbar />
      <div style={{ padding: "20px" }}>
        <NewsBoard />
      </div>
    </div>
  );
};

export default App;
